http://creativecommons.org/licenses/by-sa/3.0/
Provided the code remains open.