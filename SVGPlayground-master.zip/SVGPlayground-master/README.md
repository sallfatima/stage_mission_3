SVGPlayground
=============

Some Python generated SVG pie charts, bubbles and shit

Ad Circles: Big kudos to http://stackoverflow.com/users/376728/aaronasterling

Examples
--------
![Example 1](http://karms.biz/share/circle6.svg)
![Example 2](http://karms.biz/share/circle3.svg)
![Example 3](http://karms.biz/share/circle.svg)