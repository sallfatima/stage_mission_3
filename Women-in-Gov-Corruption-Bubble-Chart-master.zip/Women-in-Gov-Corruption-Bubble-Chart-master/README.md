# Women-in-Gov-Corruption-Bubble-Chart
This is an animated bubble chart that compares the percentage of women in national parliaments in 179 countries to the countries' ratings on the Corruption Perceptions Index, from 1997 to 2015. This project was modeled after Dr. Hans Rosling's famous bubble chart comparing global GDP and life expectancy over the course of two centuries.  
02/06/2018 - We went over our project proposal, started drafting our languages, and set up timelines fo the project. 
 By Thursday, 08 See if I can find 1997-2016 CPI data
 by Tuesday, 13 Have completely cleaned data. 
