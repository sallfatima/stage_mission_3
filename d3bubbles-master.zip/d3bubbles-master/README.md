# D3 Bubble Chart
##### *Each Bubble is an investment fund. Bubbles' color depends on the attractiveness of investment. Bubble's size depend on a finance benchmark summarizing fund information*

#### **Bl.ock:** [D3 Bubble Chart](https://bl.ocks.org/alexkzm/5a101c13fbff54b945bb9634552db9b4)

