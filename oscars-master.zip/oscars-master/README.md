# oscars
D3.js bubble chart of Best Picture Oscar Nominees and their production budgets.

I took an <a href = "https://www.udacity.com/course/viewer#!/c-ud507/l-3068848585/m-3095208694">online course in d3</a> and decided to convert a <a href="http://www.telegraph.co.uk/culture/film/oscars/10665252/Oscars-how-much-does-it-cost-to-win-Best-Picture.html">previous visualisation</a> I'd made in Tableau to d3.

It works better on mobile now and is responsive to screen width.

I've also included the code from an intermediate step where I recreated the same graphic using <a href="http://dimplejs.org/">dimple.js</a> which is a library built on top of d3.
